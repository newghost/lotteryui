#!/bin/bash
echo "start sitetest"

#change current dir, in order to call it from anywhere.
cd $(dirname $0)

while true; do
  node enlogic.js

  echo "Server stop working because of unknow reason, waiting...\r\n\r\n\r\n\r\n"
  sleep 30
done