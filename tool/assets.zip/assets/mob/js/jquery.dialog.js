(function($) {

  $.fn.dialog = function(method, options) {

    var $this = $(this);

    //handle: $().datagrid({column: [[]]})
    if (method.constructor == Object) {
    }

    if (method == "destory") {
      
    }

    return $this;
  };

})(jQuery);