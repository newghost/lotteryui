(function($) {

  $.fn.datagrid = function(method, options) {

    var $this = $(this);

    //handle: $().datagrid({column: [[]]})
    if (method.constructor == Object) {
      var columns = method.columns;
 
      if (columns) {
        $("thead", $this).size() < 1
          && $this.append("<thead></thead>");

        var header = [];

        header.push("<tr>");
        for (var i = 0, l = columns[0].length; i < l; i++) {
          var col = columns[0][i];
          header.push(
            '<th data-field="{1}">{0}</th>'.format(col.title, col.field)
          );
        }
        header.push("</tr>")

        $this
          //.removeClass("c1 c2 c3 c4 c5 c6 c7 c8 c9 c10 c11 c12")
          //.addClass("c" + l)
          .addClass("data")
          .data("columns", columns);

        $("thead", $this).html(header.join(''));
      }
    }

    //handle: $().datagrid("loadData", {rows: []})
    if (method == "loadData") {
      var rows = options.rows;

      var body = [];

      body.push("<tbody>");
      if (rows) {
        var columns = $this.data("columns");
        for (var i = 0, l = rows.length; i < l; i++) {
          body.push("<tr>")
          for (var j = 0, m = columns[0].length; j < m; j++) {
            body.push(
              "<td>{0}</td>".format(rows[i][columns[0][j].field])
            );
          };
          body.push("</tr>")
        };
      }
      body.push("</tbody>");

      $("tbody", $this).remove();
      $this.append(body.join(''));
    }

    if (method == "getColumnFields") {
      return $this.data("columns");
    }

    return $this;
  };

})(jQuery);