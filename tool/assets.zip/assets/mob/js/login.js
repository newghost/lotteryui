/*
Login
*/
(function() {

  EL.Login = function(model) {

    var $mask = $("#loading").hide();

    var $loginDialog = $("#login"),
        $loginmsg = $("#loginmsg"),
        $username = $("#username"),
        $password = $("#password"),
        $logform = $("#frlogin");

    /*
    $loginDialog.dialog({
      title : '<div class="icon-users">{0}</div>'.format(model.title),
      width: 285, height: "auto",
      modal: true, resizable: false,
      buttons: [
        {
          text: model.login,
          click: function() {
            submitHandler();
          }
        },
        {
          text: model.clear,
          click: function() {
            $("label.error").hide();
            $logform[0].reset();
          }
        }
      ]
    });
    */

    //hide clse button
    //$(".ui-dialog-titlebar-close").hide();

    //$loginDialog.height("auto");

    function submitHandler(e) {
      if (!$logform.valid()) {
        return false;
      }

      e && e.preventDefault();

      $mask.show();

      /*
      if (!loginPolicyCheck()) {
        $loginmsg
          .html('You have exceeded your login attempts, please wait for ' + logset["blocktimeout"] + " minutes, and try it again.")
          .show();

        return false;
      }
      */

      var cookie = 0,
          username = $username.val(),
          password = $password.val(),
          tocken = {"cookie": cookie, "username": username, "password": password};

      $loginmsg.html("").hide();

      $.ajax({
        url: "xhrlogin.jsp", type: "post",
        data: JSON.stringify(tocken),
        dataType: "json",
        success: function(cookie) {

          var authCookieId_Value = parseInt(cookie.cookie);

          if (authCookieId_Value) {
            //$.removeCookie(cookieName, {path:"/"} );
            $.cookie("elid", authCookieId_Value);
            //$.cookie("authCookieId", username);
            //$.cookie(username, authCookieId_Value);

            location.href = "#dashboard";
          }
        },
        error: function(req) {
          $mask.hide();

          var msg = model.authfail;

          req.status && (req.status != 401) && (msg = AJAXSTATUS[req.status]);

          $loginmsg
            .html(msg)
            .show();
        }
      });
    }

    $logform
      .submit(submitHandler)
      .validate({
        rules: {
          username: {
            required: true
            //, minlength: 3
          },
          password: {
            required: true
            //, minlength: 8
          }
        }
      });

    $("#btnClear").mousedown(function() {
      $("label.error").hide();
      $logform[0].reset();
    });
    $("#btnLogin").mousedown(submitHandler);

    //Press Enter to submit the form (fix for IE)
    /*
    function onKeyUp(e) {
      if (e.keyCode == 13) submitHandler();
    };
    $username.keyup(onKeyUp);
    $password.keyup(onKeyUp);
    */

    //Login Policy: Block User
    /*
    var cookieName = "logtag",
        logtag = { num: 0, time: new Date() },
        logset ;

    var loginPolicyCheck = function() {

      if (logset && logset["chkuserblocking"]) {
        if (logtag.num >= logset["maxnumfailedlogins"]
          && (new Date() - new Date(logtag.time) < logset["blocktimeout"] * 60 * 1000)
        ) {
          return false;
        }
      }

      return true;
    };

    //Increase logtag.num and save to cookie
    var loginPolicySet = function(num) {
      logtag.num = logtag.num + num;
      logtag.time = new Date();

      $.cookie(cookieName, JSON.stringify(logtag) , {path: "/", expires: 16});
    };

    var loginPolicyHandle = function(data) {
      logset = data;

      if (logset["chkuserblocking"]) {
        !$.cookie(cookieName) && loginPolicySet(0);
        logtag = JSON.parse( $.cookie(cookieName));
      }
    };

    var loginPolicyGet = function() {
      $.ajax({
        url: "xhrloginsetget.jsp",
        type: "post", data: JSON.stringify({cookie:0}),
        dataType: "json",
        success: loginPolicyHandle
      });
    };

    loginPolicyGet();
    */

  };

})();