/*
Namespace of Company
*/
/*
Discovery PDU
*/
EL.Discovery = function() {

  var DISCOVERY = "DISCOVERY";

  var iniList = function() {
    var $items = $("#pdus > li");
    $items.click(function(e) {
      var $this = $(this);
      $items.removeClass("selected");
      $this.addClass("selected");

      $("#txtpdu").val($this.text().trim());
    });
  };

  var refresh = function() {
    $("#pdus").html(ELMob.readFile(DISCOVERY));
    iniList();
  };

  var addList = function() {
    var pdu = $("#txtpdu").val(),
        isNew = true,
        $list = $("#pdus li");

    $list.each(function() {
      var $this = $(this);
      if (pdu.trim() == $this.text().trim()) {
        isNew = false;
        return;
      }
    });

    if (isNew) {
      var $item = $("<li>" + pdu + "</li>");

      $list.size()
        ? $list.eq(0).before($item)
        : $("#pdus").append($item);

      iniList();
    } else {
      Msg.alert("Already in the list.");
    }
  };

  var remove = function() {
    var $item = $("#pdus > li.selected");

    if ($item.size()) {
      $item.remove();
    } else {
      Msg.alert("Please select one item");
    }
  };

  $("#login").mousedown(function(e) {
    var url = $("#txtpdu").val();

    if (!url) return;

    url.indexOf("http") < 0
      ? (location.href = "http://" + url)
      : (location.href = url);
  });

  $("#add").mousedown(function(e) {
    addList();
    ELMob.writeFile(DISCOVERY, $("#pdus").html());
  });

  $("#remove").mousedown(function(e) {
    remove();
    ELMob.writeFile(DISCOVERY, $("#pdus").html());
  });

  $("#clear").mousedown(function(e) {
    ELMob.writeFile(DISCOVERY, "");
    refresh();
  });

  refresh();
};

$("#pdus").size() && EL.Discovery();

/*
Login
*/
/*
(function() {

  EL.Login = function(model) {

    var $username = $("#username"),
        $password = $("#password"),
        $btnlogin = $("#btnlogin");

    function submitHandler(e) {
      e && e.preventDefault();

      Nav.loading = 1;

      var cookie = 0,
          username = $username.val(),
          password = $password.val(),
          tocken = {"cookie": cookie, "username": username, "password": password};

      $.ajax({
        url: "/xhrlogin.jsp", type: "post",
        data: JSON.stringify(tocken),
        dataType: "json",
        success: function(cookie) {
          var authCookieId_Value = parseInt(cookie.cookie);

          if (authCookieId_Value) {
            $.cookie("elid", authCookieId_Value);

            Nav.loading = 0;
            location.href = "#outlets";
            //Nav.change("outlets");

          }
        },
        error: function(req) {
          Nav.loading = 0;

          var msg = 'Authentication failed';
          req.status && (req.status != 401) && (msg = AJAXSTATUS[req.status]);
          Msg.alert(msg);
        }
      });
    }

    $btnlogin.click(submitHandler);
  };

  EL.Login();
})();
*/

/*
Navigation buttons: back
*/
/*
$(".back").mousedown(function(e) {
  e.preventDefault();
  history.back();
});
*/
$(".home").mousedown(function(e) {
  ELMob.loadPage("discovery.html");  
});


/*
Authentication

EL.Auth = {
  getJSON: function() {
    return { cookie: parseInt($.cookie("elid")) }
  }
  , getToken: function() {
     JSON.stringify(this.getJSON());
  }
  , getTocken: function() {
    return EL.Auth.getToken();
  }
};
*/

/*
Outlet

EL.Outlets = function() {
  var $outlets = $("#outs"),
      $powstat = $("#powstat"),
      $powsbtn = $("#powsbtn");

  $outlets.html('');

  $.ajax({
    url: "/xhroutgetgrid.jsp",
    type:"post", data: JSON.stringify($.extend(EL.Auth.getJSON(), { pduid: 1 })),
    dataType:"json",
    success: function(rows) {
      var outs = [];
      rows.forEach(function(row) {
        outs.push("<li>" + row.name + "</li>");
      });

      $outlets.html(outs.join(''));

      Nav.update();
      initOuts();
    }
  });

  var initOuts = function() {
    $("#outs > li").click(function(e) {
      var $outlet = $(this);

      $outlet.hasClass("selected")
        ? $outlet.removeClass("selected")
        : $outlet.addClass("selected");
    });
  };

  var setPower = function(e) {
    e.preventDefault();

    //get selected outlet value
    var $outletItems = $("#outs > li");

    var value = 0,
        powCtrlVal = parseInt($powstat.val());

    for(var i = 0, len = $outletItems.size(); i < len; i++) {
      if ($outletItems.eq(i).hasClass("selected")) {
        value = (1 << i) | value;
      }
    }

    var outlet1 = value & 16777215,
        outlet2 = value >>> 24;

    //save token
    var saveToken = $.extend(
      EL.Auth.getJSON(),
      {
        pduid : 1,
        powstat: powCtrlVal,
        outlet1: outlet1,
        outlet2: outlet2
      }
    );

    var savePowCtrlHandler = function(obj) {
      console.log(obj);
    };

    $.ajax({
      url: "/xhroutpowstatset.jsp",
      type:"post", data: JSON.stringify(saveToken),
      dataType:"json",
      success: savePowCtrlHandler
    });
  };

  var initPow = function() {
    for(k in POWERCTRLTYPE) {
      var option = new Option(POWERCTRLTYPE[k], parseInt(k));
      $powstat[0].add(option);
    }

    $powsbtn.mousedown(setPower);
  };

  initPow();
};
*/

(typeof ELMob == "undefined") && $(document.body).addClass("web");


/*Debug Info*/
if (typeof console == "undefined") {
  var logArr = window.logArr = [];
  console = window.console = {
    log : function() {
      logArr.push(arguments);
      //$(".lot-nav").append(Array.prototype.join.call(arguments) + ', ');
    }
  };
}