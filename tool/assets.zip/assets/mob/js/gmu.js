/*mob/js/gmu/zepto.extend.js*/
/**
 * @name Extend
 * @file 对Zepto做了些扩展，以下所有JS都依赖与此文件
 * @desc 对Zepto一些扩展，组件必须依赖
 * @import core/zepto.js
 */


//     Zepto.js
//     (c) 2010-2012 Thomas Fuchs
//     Zepto.js may be freely distributed under the MIT license.

// The following code is heavily inspired by jQuery's $.fn.data()

;(function($) {
    var data = {}, dataAttr = $.fn.data, camelize = $.zepto.camelize,
        exp = $.expando = 'Zepto' + (+new Date())

    // Get value from node:
    // 1. first try key as given,
    // 2. then try camelized key,
    // 3. fall back to reading "data-*" attribute.
    function getData(node, name) {
        var id = node[exp], store = id && data[id]
        if (name === undefined) return store || setData(node)
        else {
            if (store) {
                if (name in store) return store[name]
                var camelName = camelize(name)
                if (camelName in store) return store[camelName]
            }
            return dataAttr.call($(node), name)
        }
    }

    // Store value under camelized key on node
    function setData(node, name, value) {
        var id = node[exp] || (node[exp] = ++$.uuid),
            store = data[id] || (data[id] = attributeData(node))
        if (name !== undefined) store[camelize(name)] = value
        return store
    }

    // Read all "data-*" attributes from a node
    function attributeData(node) {
        var store = {}
        $.each(node.attributes, function(i, attr){
            if (attr.name.indexOf('data-') == 0)
                store[camelize(attr.name.replace('data-', ''))] = attr.value
        })
        return store
    }

    $.fn.data = function(name, value) {
        return value === undefined ?
            // set multiple values via object
            $.isPlainObject(name) ?
                this.each(function(i, node){
                    $.each(name, function(key, value){ setData(node, key, value) })
                }) :
                // get value from first element
                this.length == 0 ? undefined : getData(this[0], name) :
            // set value on all elements
            this.each(function(){ setData(this, name, value) })
    }

    $.fn.removeData = function(names) {
        if (typeof names == 'string') names = names.split(/\s+/)
        return this.each(function(){
            var id = this[exp], store = id && data[id]
            if (store) $.each(names, function(){ delete store[camelize(this)] })
        })
    }
})(Zepto);

(function($){
    var rootNodeRE = /^(?:body|html)$/i;
    $.extend($.fn, {
        offsetParent: function() {
            return $($.map(this, function(el){
                var parent = el.offsetParent || document.body
                while (parent && !rootNodeRE.test(parent.nodeName) && $(parent).css("position") == "static")
                    parent = parent.offsetParent
                return parent
            }));
        },
        scrollTop: function(){
            if (!this.length) return
            return ('scrollTop' in this[0]) ? this[0].scrollTop : this[0].scrollY
        }
    });
    $.extend($, {
        contains: function(parent, node) {
            /**
             * modified by chenluyang
             * @reason ios4 safari下，无法判断包含文字节点的情况
             * @original return parent !== node && parent.contains(node)
             */
            return parent.compareDocumentPosition
                ? !!(parent.compareDocumentPosition(node) & 16)
                : parent !== node && parent.contains(node)
        }
    });
})(Zepto);


//Core.js
;(function($) {
    //扩展在Zepto静态类上
    $.extend($, {
        /**
         * @grammar $.toString(obj)  ⇒ string
         * @name $.toString
         * @desc toString转化
         */
        toString: function(obj) {
            return Object.prototype.toString.call(obj);
        },

        /**
         * @desc 从集合中截取部分数据，这里说的集合，可以是数组，也可以是跟数组性质很像的对象，比如arguments
         * @name $.slice
         * @grammar $.slice(collection, [index])  ⇒ array
         * @example (function(){
         *     var args = $.slice(arguments, 2);
         *     console.log(args); // => [3]
         * })(1, 2, 3);
         */
        slice: function(array, index) {
            return Array.prototype.slice.call(array, index || 0);
        },

        /**
         * @name $.later
         * @grammar $.later(fn, [when, [periodic, [context, [data]]]])  ⇒ timer
         * @desc 延迟执行fn
         * **参数:**
         * - ***fn***: 将要延时执行的方法
         * - ***when***: *可选(默认 0)* 什么时间后执行
         * - ***periodic***: *可选(默认 false)* 设定是否是周期性的执行
         * - ***context***: *可选(默认 undefined)* 给方法设定上下文
         * - ***data***: *可选(默认 undefined)* 给方法设定传入参数
         * @example $.later(function(str){
         *     console.log(this.name + ' ' + str); // => Example hello
         * }, 250, false, {name:'Example'}, ['hello']);
         */
        later: function(fn, when, periodic, context, data) {
            return window['set' + (periodic ? 'Interval' : 'Timeout')](function() {
                fn.apply(context, data);
            }, when || 0);
        },

        /**
         * @desc 解析模版
         * @grammar $.parseTpl(str, data)  ⇒ string
         * @name $.parseTpl
         * @example var str = "<p><%=name%></p>",
         * obj = {name: 'ajean'};
         * console.log($.parseTpl(str, data)); // => <p>ajean</p>
         */
        parseTpl: function(str, data) {
            var tmpl = 'var __p=[],print=function(){__p.push.apply(__p,arguments);};' + 'with(obj||{}){__p.push(\'' + str.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/<%=([\s\S]+?)%>/g, function(match, code) {
                return "'," + code.replace(/\\'/g, "'") + ",'";
            }).replace(/<%([\s\S]+?)%>/g, function(match, code) {
                    return "');" + code.replace(/\\'/g, "'").replace(/[\r\n\t]/g, ' ') + "__p.push('";
                }).replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t') + "');}return __p.join('');";
            var func = new Function('obj', tmpl);
            return data ? func(data) : func;
        },

        /**
         * @desc 减少执行频率, 多次调用，在指定的时间内，只会执行一次。
         * **options:**
         * - ***delay***: 延时时间
         * - ***fn***: 被稀释的方法
         * - ***debounce_mode***: 是否开启防震动模式, true:start, false:end
         *
         * <code type="text">||||||||||||||||||||||||| (空闲) |||||||||||||||||||||||||
         * X    X    X    X    X    X      X    X    X    X    X    X</code>
         *
         * @grammar $.throttle(delay, fn) ⇒ function
         * @name $.throttle
         * @example var touchmoveHander = function(){
         *     //....
         * }
         * //绑定事件
         * $(document).bind('touchmove', $.throttle(250, touchmoveHander));//频繁滚动，每250ms，执行一次touchmoveHandler
         *
         * //解绑事件
         * $(document).unbind('touchmove', touchmoveHander);//注意这里面unbind还是touchmoveHander,而不是$.throttle返回的function, 当然unbind那个也是一样的效果
         *
         */
        throttle: function(delay, fn, debounce_mode) {
            var last = 0,
                timeId;

            if (typeof fn !== 'function') {
                debounce_mode = fn;
                fn = delay;
                delay = 250;
            }

            function wrapper() {
                var that = this,
                    period = Date.now() - last,
                    args = arguments;

                function exec() {
                    last = Date.now();
                    fn.apply(that, args);
                };

                function clear() {
                    timeId = undefined;
                };

                if (debounce_mode && !timeId) {
                    // debounce模式 && 第一次调用
                    exec();
                }

                timeId && clearTimeout(timeId);
                if (debounce_mode === undefined && period > delay) {
                    // throttle, 执行到了delay时间
                    exec();
                } else {
                    // debounce, 如果是start就clearTimeout
                    timeId = setTimeout(debounce_mode ? clear : exec, debounce_mode === undefined ? delay - period : delay);
                }
            };
            // for event bind | unbind
            wrapper._zid = fn._zid = fn._zid || $.proxy(fn)._zid;
            return wrapper;
        },

        /**
         * @desc 减少执行频率, 在指定的时间内, 多次调用，只会执行一次。
         * **options:**
         * - ***delay***: 延时时间
         * - ***fn***: 被稀释的方法
         * - ***t***: 指定是在开始处执行，还是结束是执行, true:start, false:end
         *
         * 非at_begin模式
         * <code type="text">||||||||||||||||||||||||| (空闲) |||||||||||||||||||||||||
         *                         X                                X</code>
         * at_begin模式
         * <code type="text">||||||||||||||||||||||||| (空闲) |||||||||||||||||||||||||
         * X                                X                        </code>
         *
         * @grammar $.debounce(delay, fn[, at_begin]) ⇒ function
         * @name $.debounce
         * @example var touchmoveHander = function(){
         *     //....
         * }
         * //绑定事件
         * $(document).bind('touchmove', $.debounce(250, touchmoveHander));//频繁滚动，只要间隔时间不大于250ms, 在一系列移动后，只会执行一次
         *
         * //解绑事件
         * $(document).unbind('touchmove', touchmoveHander);//注意这里面unbind还是touchmoveHander,而不是$.debounce返回的function, 当然unbind那个也是一样的效果
         */
        debounce: function(delay, fn, t) {
            return fn === undefined ? $.throttle(250, delay, false) : $.throttle(delay, fn, t === undefined ? false : t !== false);
        }
    });

    /**
     * 扩展类型判断
     * @param {Any} obj
     * @see isString, isBoolean, isRegExp, isNumber, isDate, isObject, isNull, isUdefined
     */
    /**
     * @name $.isString
     * @grammar $.isString(val)  ⇒ Boolean
     * @desc 判断变量类型是否为***String***
     * @example console.log($.isString({}));// => false
     * console.log($.isString(123));// => false
     * console.log($.isString('123'));// => true
     */
    /**
     * @name $.isBoolean
     * @grammar $.isBoolean(val)  ⇒ Boolean
     * @desc 判断变量类型是否为***Boolean***
     * @example console.log($.isBoolean(1));// => false
     * console.log($.isBoolean('true'));// => false
     * console.log($.isBoolean(false));// => true
     */
    /**
     * @name $.isRegExp
     * @grammar $.isRegExp(val)  ⇒ Boolean
     * @desc 判断变量类型是否为***RegExp***
     * @example console.log($.isRegExp(1));// => false
     * console.log($.isRegExp('test'));// => false
     * console.log($.isRegExp(/test/));// => true
     */
    /**
     * @name $.isNumber
     * @grammar $.isNumber(val)  ⇒ Boolean
     * @desc 判断变量类型是否为***Number***
     * @example console.log($.isNumber('123'));// => false
     * console.log($.isNumber(true));// => false
     * console.log($.isNumber(123));// => true
     */
    /**
     * @name $.isDate
     * @grammar $.isDate(val)  ⇒ Boolean
     * @desc 判断变量类型是否为***Date***
     * @example console.log($.isDate('123'));// => false
     * console.log($.isDate('2012-12-12'));// => false
     * console.log($.isDate(new Date()));// => true
     */
    /**
     * @name $.isObject
     * @grammar $.isObject(val)  ⇒ Boolean
     * @desc 判断变量类型是否为***Object***
     * @example console.log($.isObject('123'));// => false
     * console.log($.isObject(true));// => false
     * console.log($.isObject({}));// => true
     */
    /**
     * @name $.isNull
     * @grammar $.isNull(val)  ⇒ Boolean
     * @desc 判断变量类型是否为***null***
     * @example console.log($.isNull(false));// => false
     * console.log($.isNull(0));// => false
     * console.log($.isNull(null));// => true
     */
    /**
     * @name $.isUndefined
     * @grammar $.isUndefined(val)  ⇒ Boolean
     * @desc 判断变量类型是否为***undefined***
     * @example
     * console.log($.isUndefined(false));// => false
     * console.log($.isUndefined(0));// => false
     * console.log($.isUndefined(a));// => true
     */
    $.each("String Boolean RegExp Number Date Object Null Undefined".split(" "), function(i, name) {
        var fnbody = '';
        switch (name) {
            case 'Null':
                fnbody = 'obj === null';
                break;
            case 'Undefined':
                fnbody = 'obj === undefined';
                break;
            default:
                //fnbody = "new RegExp('" + name + "]', 'i').test($.toString(obj))";
                fnbody = "new RegExp('" + name + "]', 'i').test(Object.prototype.toString.call(obj))";//解决zepto与jQuery共存时报错的问题，$被jQuery占用了。
        }
        $['is' + name] = new Function('obj', "return " + fnbody);
    });

})(Zepto);

//Support.js
(function($, undefined) {
    var ua = navigator.userAgent,
        na = navigator.appVersion,
        br = $.browser;

    /**
     * @name $.browser
     * @desc 扩展zepto中对browser的检测
     *
     * **可用属性**
     * - ***qq*** 检测qq浏览器
     * - ***chrome*** 检测chrome浏览器
     * - ***uc*** 检测uc浏览器
     * - ***version*** 检测浏览器版本
     *
     * @example
     * if ($.browser.qq) {      //在qq浏览器上打出此log
     *     console.log('this is qq browser');
     * }
     */
    $.extend($.browser, {
        qq: /qq/i.test(ua),
        chrome: /chrome/i.test(ua) || /CriOS/i.test(ua),
        uc: /UC/i.test(ua) || /UC/i.test(na)
    });

    $.browser.uc = $.browser.uc || !$.browser.qq && !$.browser.chrome && !/safari/i.test(ua);

    try {
        $.browser.version = br.uc ? na.match(/UC(?:Browser)?\/([\d.]+)/)[1] : br.qq ? ua.match(/MQQBrowser\/([\d.]+)/)[1] : br.chrome ? ua.match(/(?:CriOS|Chrome)\/([\d.]+)/)[1] : br.version;
    } catch (e) {}


    /**
     * @name $.support
     * @desc 检测设备对某些属性或方法的支持情况
     *
     * **可用属性**
     * - ***orientation*** 检测是否支持转屏事件，UC中存在orientaion，但转屏不会触发该事件，故UC属于不支持转屏事件(iOS 4上qq, chrome都有这个现象)
     * - ***touch*** 检测是否支持touch相关事件
     * - ***cssTransitions*** 检测是否支持css3的transition
     * - ***has3d*** 检测是否支持translate3d的硬件加速
     *
     * @example
     * if ($.support.has3d) {      //在支持3d的设备上使用
     *     console.log('you can use transtion3d');
     * }
     */
    $.support = $.extend($.support || {}, {
        orientation: !($.browser.uc || (parseFloat($.os.version)<5 && ($.browser.qq || $.browser.chrome))) && "orientation" in window && "onorientationchange" in window,
        touch: "ontouchend" in document,
        cssTransitions: "WebKitTransitionEvent" in window,
        has3d: 'WebKitCSSMatrix' in window && 'm11' in new WebKitCSSMatrix()

    });

})(Zepto);

//Event.js
(function($) {
    /** detect orientation change */
    $(document).ready(function () {
        var getOrt = "matchMedia" in window ? function(){
                return window.matchMedia("(orientation: portrait)").matches?'portrait':'landscape';
            }:function(){
                var elem = document.documentElement;
                return elem.clientWidth / Math.max(elem.clientHeight, 320) < 1.1 ? "portrait" : "landscape";
            },
            lastOrt = getOrt(),
            handler = function(e) {
                if(e.type == 'orientationchange'){
                    return $(window).trigger('ortchange');
                }
                maxTry = 20;
                clearInterval(timer);
                timer = $.later(function() {
                    var curOrt = getOrt();
                    if (lastOrt !== curOrt) {
                        lastOrt = curOrt;
                        clearInterval(timer);
                        $(window).trigger('ortchange');
                    } else if(--maxTry){//最多尝试20次
                        clearInterval(timer);
                    }
                }, 50, true);
            },
            timer, maxTry;
        $(window).bind($.support.orientation ? 'orientationchange' : 'resize', $.debounce(handler));
    });

    /**
     * @name Trigger Events
     * @theme event
     * @desc 扩展的事件
     * - ***scrollStop*** : scroll停下来时触发, 考虑前进或者后退后scroll事件不触发情况。
     * - ***ortchange*** : 当转屏的时候触发，兼容uc和其他不支持orientationchange的设备
     * @example $(document).on('scrollStop', function () {        //scroll停下来时显示scrollStop
     *     console.log('scrollStop');
     * });
     *
     * $(document).on('ortchange', function () {        //当转屏的时候触发
     *     console.log('ortchange');
     * });
     */
    /** dispatch scrollStop */
    function _registerScrollStop(){
        $(window).on('scroll', $.debounce(80, function() {
            $(document).trigger('scrollStop');
        }, false));
    }
    //在离开页面，前进或后退回到页面后，重新绑定scroll, 需要off掉所有的scroll，否则scroll时间不触发
    function _touchstartHander() {
        $(window).off('scroll');
        _registerScrollStop();
    }
    _registerScrollStop();
    $(window).on('pageshow', function(e){
        if(e.persisted) {//如果是从bfcache中加载页面
            $(document).off('touchstart', _touchstartHander).one('touchstart', _touchstartHander);
        }
    });
})(Zepto);

/*mob/js/gmu/zepto.ui.js*/
/**
 * @file 所有UI组件的基类，通过它可以简单的快速的创建新的组件。
 * @name UI 基类
 * @short Zepto UI
 * @desc 所有UI组件的基类，通过它可以简单的快速的创建新的组件。
 * @import core/zepto.js, core/zepto.extend.js
 */
(function($, undefined) {
    $.ui = $.ui || {
        version: '2.0.3',

        guid: _guid,

        /**
         * @name $.ui.define
         * @grammar $.ui.define(name, data[, superClass]) ⇒ undefined
         * @desc 定义组件,
         * - ''name'' 组件名称
         * - ''data'' 对象，设置此组件的prototype。可以添加属性或方法
         * - ''superClass'' 基类，指定此组件基于哪个现有组件，默认为Widget基类
         * **示例:**
         * <code type="javascript">
         * $.ui.define('helloworld', {
         *     _data: {
         *         opt1: null
         *     },
         *     enable: function(){
         *         //...
         *     }
         * });
         * </code>
         *
         * **定义完后，就可以通过以下方式使用了**
         *<code type="javascript">
         * var instance = $.ui.helloworld({opt1: true});
         * instance.enable();
         *
         * //或者
         * $('#id').helloworld({opt1:true});
         * //...later
         * $('#id').helloworld('enable');
         * </code>
         *
         * **Tips**
         * 1. 通过Zepto对象上的组件方法，可以直接实例话组件, 如: $('#btn').button({label: 'abc'});
         * 2. 通过Zepto对象上的组件方法，传入字符串this, 可以获得组件实例，如：var btn = $('#btn').button('this');
         * 3. 通过Zepto对象上的组件方法，可以直接调用组件方法，第一个参数用来指定方法名，之后的参数作为方法参数，如: $('#btn').button('setIcon', 'home');
         * 4. 在子类中，如覆写了某个方法，可以在方法中通过this.$super()方法调用父级方法。如：this.$super('enable');
         */
        define: function(name, data, superClass) {
            if(superClass) data.inherit = superClass;
            var Class = $.ui[name] = _createClass(function(el, options) {
                var obj = _createObject(Class.prototype, {
                    _id: $.parseTpl(tpl, {
                        name: name,
                        id: _guid()
                    })
                });
                obj._createWidget.call(obj, el, options,Class.plugins);
                return obj;
            }, data);
            return _zeptoLize(name, Class);
        },

        /**
         * @name $.ui.isWidget()
         * @grammar $.ui.isWidget(obj) ⇒ boolean
         * @grammar $.ui.isWidget(obj, name) ⇒ boolean
         * @desc 判断obj是不是widget实例
         *
         * **参数**
         * - ''obj'' 用于检测的对象
         * - ''name'' 可选，默认监测是不是''widget''(基类)的实例，可以传入组件名字如''button''。作用将变为obj是不是button组件实例。
         * @param obj
         * @param name
         * @example
         *
         * var btn = $.ui.button(),
         *     dialog = $.ui.dialog();
         *
         * console.log($.isWidget(btn)); // => true
         * console.log($.isWidget(dialog)); // => true
         * console.log($.isWidget(btn, 'button')); // => true
         * console.log($.isWidget(dialog, 'button')); // => false
         * console.log($.isWidget(btn, 'noexist')); // => false
         */
        isWidget: function(obj, name){
            return obj instanceof (name===undefined ? _widget: $.ui[name] || _blankFn);
        }
    };

    var id = 1,
        _blankFn = function(){},
        tpl = '<%=name%>-<%=id%>',
        uikey = 'gmu-widget';
        
    /**
     * generate guid
     */
    function _guid() {
        return id++;
    };

    function _createObject(proto, data) {
        var obj = {};
        Object.create ? obj = Object.create(proto) : obj.__proto__ = proto;
        return $.extend(obj, data || {});
    }

    function _createClass(Class, data) {
        if (data) {
            _process(Class, data);
            $.extend(Class.prototype, data);
        }
        return $.extend(Class, {
            plugins: [],
            register: function(fn) {
                if ($.isObject(fn)) {
                    $.extend(this.prototype,fn);
                    return;
                }
                this.plugins.push(fn);
            }
        });
    }

    /**
     * handle inherit & _data
     */
    function _process(Class, data) {
        var superClass = data.inherit || _widget,
            proto = superClass.prototype,
            obj;
        obj = Class.prototype = _createObject(proto, {
            $factory: Class,
            $super: function(key) {
                var fn = proto[key];
                return $.isFunction(fn) ? fn.apply(this, $.slice(arguments, 1)) : fn;
            }
        });
        obj._data = $.extend({}, proto._data, data._data);
        delete data._data;
        return Class;
    }

    /**
     * 强制setup模式
     * @grammar $(selector).dialog(opts);
     */
    function _zeptoLize(name) {
        $.fn[name] = function(opts) {

            var ret, obj,args = $.slice(arguments, 1);
            $.each(this,function(i,el){
                obj = $(el).data(uikey + name) ||  $.ui[name](el, $.extend($.isPlainObject(opts) ?  opts : {},{
                    setup: true
                }));
                if ($.isString(opts)) {
                    ret = $.isFunction(obj[opts]) && obj[opts].apply(obj, args);
                    if (opts == 'this' || ret !== obj && ret !== undefined) {
                        return false;
                    }
                    ret = null;
                }
            });
            //ret 为真就是要返回ui实例之外的内容
            //obj 'this'时返回
            //其他都是返回zepto实例
            return ret || (opts == 'this' ? obj : this);
        };
    }
    /**
     * @name widget基类
     * @desc GMU所有的组件都是此类的子类，即以下此类里面的方法都可在其他组建中调用。
     */
    var _widget = function() {};
    $.extend(_widget.prototype, {
        _data: {
            status: true
        },

        /**
         * @name data
         * @grammar data(key) ⇒ value
         * @grammar data(key, value) ⇒ value
         * @desc 设置或者获取options, 所有组件中的配置项都可以通过此方法得到。
         * @example
         * $('a#btn').button({label: '按钮'});
         * console.log($('a#btn').button('data', 'label'));// => 按钮
         */
        data: function(key, val) {
            var _data = this._data;
            if ($.isObject(key)) return $.extend(_data, key);
            else return !$.isUndefined(val) ? _data[key] = val : _data[key];
        },

        /**
         * common constructor
         */
        _createWidget: function(el, opts,plugins) {

            if ($.isObject(el)) {
                opts = el || {};
                el = undefined;
            }

            var data = $.extend({}, this._data, opts);
            $.extend(this, {
                _el: el ? $(el) : undefined,
                _data: data
            });

            //触发plugins
            var me = this;
            $.each(plugins,function(i,fn){
                var result = fn.apply(me);
                if(result && $.isPlainObject(result)){
                    var plugins = me._data.disablePlugin;
                    if(!plugins || $.isString(plugins) && plugins.indexOf(result.pluginName) == -1){
                        delete result.pluginName
                        $.each(result,function(key,val){
                            var orgFn;
                            if((orgFn = me[key]) && $.isFunction(val)){
                                me[key] = function(){
                                    me[key + 'Org'] = orgFn;
                                    return val.apply(me,arguments);
                                }
                            }else
                                me[key] = val;
                        })
                    }
                }
            });
            // use setup or render
            if(data.setup) this._setup(el && el.getAttribute('data-mode'));
            else this._create();
            this._init();

            var me = this,
                $el = this.trigger('init').root();
            $el.on('tap', function(e) {
                (e['bubblesList'] || (e['bubblesList'] = [])).push(me);
            });
            // record this
            $el.data(uikey + this._id.split('-')[0],this);
        },

        /**
         * @interface: use in render mod
         * @name _create
         * @desc 接口定义，子类中需要重新实现此方法，此方法在render模式时被调用。
         *
         * 所谓的render方式，即，通过以下方式初始化组件
         * <code>
         * $.ui.widgetName(options);
         * </code>
         */
        _create: function() {},

        /**
         * @interface: use in setup mod
         * @param {Boolean} data-mode use tpl mode
         * @name _setup
         * @desc 接口定义，子类中需要重新实现此方法，此方法在setup模式时被调用。第一个行参用来分辨时fullsetup，还是setup
         *
         * <code>
         * $.ui.define('helloworld', {
         *     _setup: function(mode){
         *          if(mode){
         *              //为fullsetup模式
         *          } else {
         *              //为setup模式
         *          }
         *     }
         * });
         * </code>
         *
         * 所谓的setup方式，即，先有dom，然后通过选择器，初始化Zepto后，在Zepto对象直接调用组件名方法实例化组件，如
         * <code>
         * //<div id="widget"></div>
         * $('#widget').widgetName(options);
         * </code>
         *
         * 如果用来初始化的element，设置了data-mode="true"，组件将以fullsetup模式初始化
         */
        _setup: function(mode) {},

        /**
         * @name root
         * @grammar root() ⇒ value
         * @grammar root(el) ⇒ value
         * @desc 设置或者获取根节点
         * @example
         * $('a#btn').button({label: '按钮'});
         * console.log($('a#btn').button('root'));// => a#btn
         */
        root: function(el) {
            return this._el = el || this._el;
        },

        /**
         * @name id
         * @grammar id() ⇒ value
         * @grammar id(id) ⇒ value
         * @desc 设置或者获取组件id
         */
        id: function(id) {
            return this._id = id || this._id;
        },

        /**
         * @name destroy
         * @grammar destroy() ⇒ undefined
         * @desc 注销组件
         */
        destroy: function() {
            var That = this,
                $el;
            $.each(this.data('components') || [], function(id, obj) {
                obj.destroy();
            });
            $el = this.trigger('destroy').off().root();
            $el.find('*').off();
            $el.removeData(uikey).off().remove();
            this.__proto__ = null;
            $.each(this, function(key, val) {
                delete That[key];
            });
        },

        /**
         * @name component
         * @grammar component() ⇒ array
         * @grammar component(subInstance) ⇒ instance
         * @grammar component(createFn) ⇒ instance
         * @desc 获取或者设置子组件, createFn为组件构造器，必须返回组件的实例。
         */
        component: function(createFn) {
            var list = this.data('components') || this.data('components', []);
            try {
                list.push($.isFunction(createFn) ? createFn.apply(this) : createFn);
            } catch(e) {}
            return this;
        },

        /**
         * @name on
         * @grammar on(type, handler) ⇒ instance
         * @desc 绑定事件，此事件绑定不同于zepto上绑定事件，此On的this只想组件实例，而非zepto实例
         */
        on: function(ev, callback) {
            this.root().on(ev, $.proxy(callback, this));
            return this;
        },

        /**
         * @name off
         * @grammar off(type) ⇒ instance
         * @grammar off(type, handler) ⇒ instance
         * @desc 解绑事件
         */
        off: function(ev, callback) {
            this.root().off(ev, callback);
            return this;
        },

        /**
         * @name trigger
         * @grammar trigger(type[, data]) ⇒ instance
         * @desc 触发事件, 此trigger会优先把options上的事件回调函数先执行，然后给根DOM派送事件。
         * options上回调函数可以通过e.preventDefaualt()来组织事件派发。
         */
        trigger: function(event, data) {
            event = $.isString(event) ? $.Event(event) : event;
            var onEvent = this.data(event.type),result;
            if( onEvent && $.isFunction(onEvent) ){
                event.data = data;
                result = onEvent.apply(this, [event].concat(data));
                if(result === false || event.defaultPrevented){
                    return this;
                }
            }
            this.root().trigger(event, data);
            return this;
        }
    });
})(Zepto);
/*mob/js/gmu/Chart.js*/
/**
 * DVBase继承自Widget，是图表库的基类。
 */
(function(){
	var Chart = {};
	
	$.extend(Chart, {
		INVALID_TYPE:{
				INIT:"init",
				ALL:"all",
				DATA:"data"
		},
		
		EVENT_TYPE:{
			DATA_RENDERED:"baidu_chart_data_rendered",
			DATA_SELECTED:"baidu_chart",
			CLEAR:"clear"
		},
		
		_init : function(){
			this.inCallLaterPhase = false;
        	this.invalidHash = {};
        	this.invalide(this.INVALID_TYPE.INIT);
		},
		
		_create:function(){
			//console.log("create");
		},
		
		_setup:function(){
			//console.log("setup");
		},
		
		invalide : function(prop){
        	this.invalidHash[prop] = true;
        	this.callLater();
   		},
   		
   		validate : function(){
        	for(var key in this.invalidHash){
            	delete this.invalidHash[key];
        	}
    	},
    	
    	callLater : function(){
        	if(this.inCallLaterPhase){
            	return; 
        	}
            
        	this.inCallLaterPhase = true;
        	var me = this;
        	setTimeout(function(){me.refresh.apply(me);}, 50);
    	},
    	
    	draw : function(){
    		// Chart里的draw什么都不做
        	//console.log("execute draw function in Chart");
        	
        	//this.trigger("baidu_chart_data_rendered");
    	},
    	
    	refresh : function(){
        	this.draw();
            
        	this.validate();
        	this.inCallLaterPhase = false;
        	
        	this.trigger("baidu_chart_data_rendered");
    	},
    	
    	clear : function(){
    		this.validate();
        	this.inCallLaterPhase = false;
    		this.trigger("baidu_chart_clear");
    	},
    	
    	setData : function(arr){
    		//console.log("execute setData function in Chart");
    		
    		this.invalide(this.INVALID_TYPE.ALL);
    	},
    	
    	addData : function(obj){
    		//console.log("execute addData function in Chart");
    		this.invalide(this.INVALID_TYPE.DATA);
    	}
	})
	
	$.ui.define("Chart", Chart);
})();

/*mob/js/gmu/lineChart.js*/
/**
 * @file
 * @name LineChart
 * @desc 折线图
 * @import core/zepto.js, core/zepto.extend.js, core/zepto.ui.js, chart/base/Chart.js
 */
(function(){
    /**
     * @name    $.ui.LineChart
     * @grammar $.ui.LineChart(el, options) ⇒ instance
     * @grammar $.ui.LineChart(options) ⇒ instance
     * @grammar LineChart(options) ⇒ self
     * @desc **el** 
     * css选择器, 或者zepto对象
     * 
     * 根元素选择器或者对象
     * **Options**
     * - ''width''              {Number|Percent}: (可选)图表区域的宽度，可以使像素值或者百分比。若不设置，则为父容器宽度。
     * - ''height''             {Number|Percent}: (可选)图表区域的高度，可以使像素值或者百分比。若不设置，则为父容器高度。
     * - ''backgroundColor''    {Number}: (可选)cssbackgroundColor属性。
     * - ''axisColor''          {Number}: (可选)#xxxxxx格式。坐标轴颜色。
     * - ''axisLineWidth''      {Number}: (可选)坐标轴线宽度。
     * - ''gridColor''          {Number}: (可选)#xxxxxx格式。图表网格颜色。
     * - ''gridLineWidth''      {Number}: (可选)图表网格线宽度。
     * - ''gridXStep''          {Number}: (可选)横轴间隔数。默认为1。
     * - ''gridYStep''          {Number}: (可选)纵轴间隔数。默认为1。
     * - ''showLastSplitLineX'' {Boolean} 是否展示x轴最后一条线。
     * - ''showLastSplitLineY'' {Boolean} 是否展示y轴最后一条线。
     * - ''showTouchLine''      {Boolean} 手指按下时是否展示选择线。
     * - ''enableDrag''         {Boolean} 是否允许拖拽操作。
     * - ''touchTimeout''       {Number}  手指按下多少毫秒后进入拖拽模式。
     * 
     * **Demo**
     * <codepreview href="../gmu/_examples/chart/linechart/linechart_demo.html">
     * ../gmu/_examples/chart/linechart/linchart_demo.html
     * ../gmu/_examples/chart/linechart/lineChart.css
     * </codepreview>
     */
    $.ui.define("LineChart", {
        chartWidth:0,          // 图表宽
        chartHeight:0,         // 图表高
        tipsHeight:0,          // 标注高度
        maxVal:0,              // y轴的最大值
        minVal:0,              // y轴的最小值

        LINE_CHART_OFFSET:4,   // 图表起点在Canvas中的偏移，这个值在线图中是为了边界的点不要被盖住;
        COLLISION_OFFSET:40,   //
        lines:[],
        newLines:[],
        icons:[],
        tips:[],
        
        inherit:$.ui.Chart,

        _data:{
            chartOffsetX:60,            // 图表内容在容器中x方向上的偏移量
            chartOffsetY:5,             // 图表内容在容器中y方向上的偏移量
            width:320,
            height:160,
            backgroundColor:"rgba(0, 0, 0, 0)",
            axisColor: "#999999",
            axisLineWidth:2,
            gridColor: "#cccccc",
            gridLineWidth:1,
            gridXStep:1,
            gridYStep:1,
            showLastSplitLineX:true,
            showLastSplitLineY:true,
            showTouchLine:true,
            enableDrag:true,
            touchTimeout:500
        },

        _create:function(){
            this.tipsContainer = $("<div class='tips-container'></div>");
            this.root().append(this.tipsContainer);
            this.canvas = $("<canvas class='chart-canvas'></canvas>");
            this.root().append(this.canvas);
        },

        _setup:function(){
            this.tipsContainer = $("#linechart .tips-container");
            this.canvas = $("#linechart canvas");
        },

        _init:function(){
            me = this;
            $.ui.Chart.prototype._init.call(this);
        },

        _do_init:function(){
            var rect = this.root()[0].getBoundingClientRect();
            var reg = new RegExp("([0-9]+)%$", "gi");
            if(reg.test(this.data("width"))){
                this.chartWidth = (rect.right - rect.left) * RegExp.$1 * 0.01;
            }
            this.chartWidth = this.chartWidth ? this.chartWidth : parseFloat(this.data("width")) || (rect.right - rect.left);

            reg = new RegExp("([0-9]+)%$", "gi");
            if(reg.test(this.data("height"))){
                this.chartHeight = (rect.bottom - rect.top) * RegExp.$1 * 0.01;
            }
            this.chartHeight = this.chartHeight ? this.chartHeight : parseFloat(this.data("height")) || (rect.bottom - rect.top);

            rect = this.tipsContainer[0].getBoundingClientRect();
            this.tipsHeight = rect.bottom - rect.top;

            this.canvas.attr({"width":this.chartWidth + "px", "height":this.chartHeight + "px"});
            this.canvas.css({"left":this.data("chartOffsetX")+"px", "top":(this.data("chartOffsetY") + this.tipsHeight)+"px", "background-color":this.data("backgroundColor")});

            // 注册事件 TODO...
            this.canvas.on("touchstart", this._touchStartEvent); // 因为tap没法拿到点击坐标，所以用touchstart来代替tap
            this.canvas.on("touchend", this._touchEndEvent);

            this.$touchLine = null;
        },

        _drawChart:function(){
            this._drawLabels();
            this._drawGrids();
        },

        _drawLabels:function(){
            // 绘制Category标注
            this.hlabs = this.hlabs || [];
            var $elem = this.root()[0];
            while(this.hlabs.length){
                this.hlabs.shift().remove();
            }
            var i = 0, iLen = this.categorys.length, $span, box;
            var categoryUnit = (this.chartWidth - 2 * this.LINE_CHART_OFFSET) / (this.categorys.length - 1); // x轴画线需要间隔的距离
            for(var xstep = this.data("gridXStep"); i < iLen; i+=xstep) {
                $span = $("<span class='category-label'>"+this.categorys[i]+"</span>");
                this.root().append($span);
                box = $span[0].getBoundingClientRect();
                $span.css({"top":(this.data("chartOffsetY") + this.canvas[0].offsetHeight + this.tipsHeight) + "px", "left":(this.data("chartOffsetX") + this.LINE_CHART_OFFSET + i * categoryUnit - box.width * 0.5)+"px"});
                this.hlabs.push($span);
            }
            if((i - xstep) != (iLen - 1)){  // 最后标注必须展现
                $span = $("<span class='category-label'>"+this.categorys[iLen - 1]+"</span>");
                this.root().append($span);
                box = $span[0].getBoundingClientRect();
                $span.css({"top":(this.data("chartOffsetY") + this.canvas[0].offsetHeight + this.tipsHeight) + "px", "left":(this.data("chartOffsetX") + this.chartWidth - this.LINE_CHART_OFFSET - box.width * 0.5)+"px"});
                this.hlabs.push($span);
            }

            this.vlabs = this.vlabs || [];
            while(this.vlabs.length){
                this.vlabs.shift().remove();
            }
            var valueUnit = (this.chartHeight - 2 * this.LINE_CHART_OFFSET) / (this.values.length - 1);  // y轴画线需要间隔的距离
            this.maxVal = Math.max.apply(null, this.values);
            this.minVal = Math.min.apply(null, this.values);

            for(i = 0, iLen = this.values.length, ystep = this.data("gridYStep"); i < iLen; i+=ystep){
                $span = $("<span class='value-label'>"+this.values[i]+"</span>");
                this.root().append($span);
                box = $span[0].getBoundingClientRect();
                var tmp = "";
                if(i == 0){
                    tmp = (this.data("chartOffsetY") + this.chartHeight - this.LINE_CHART_OFFSET - box.height + this.tipsHeight) + "px";
                } else {
                    tmp = (this.data("chartOffsetY") + this.chartHeight - this.LINE_CHART_OFFSET - i * valueUnit - box.height * 0.5 + this.tipsHeight) + "px;";
                }
                $span.css({"left":(this.data("chartOffsetX") - box.width - 10) + "px", "top":tmp});
                this.vlabs.push($span);
            }
            if((i - ystep) != (iLen - 1)){
                $span = $("<span class='value-label'>"+this.values[iLen - 1]+"</span>");
                this.root().append($span);
                box = $span[0].getBoundingClientRect();
                var tmp = (this.data("chartOffsetY") + this.tipsHeight + this.LINE_CHART_OFFSET - box.height * 0.5) + "px";
                $span.css({"left":(this.data("chartOffsetX") - box.width - 10) + "px", "top":tmp});
                this.vlabs.push($span);
            }
        },

        _drawGrids:function(){
            var canvas = this.canvas[0];
            var context2d = canvas.getContext("2d");
            context2d.clearRect(0, 0, canvas.width, canvas.height);

            var x1 = this.LINE_CHART_OFFSET;
            var y1 = this.LINE_CHART_OFFSET;
            var y2 = this.chartHeight - this.LINE_CHART_OFFSET;
            var x2 = this.chartWidth - this.LINE_CHART_OFFSET;
            // draw axis
            context2d.strokeStyle = this.data("axisColor");
            context2d.lineWidth = this.data("axisLineWidth");
            context2d.beginPath();
            drawLines(context2d, [{x:x1, y:y1}, {x:x1, y:y2}, {x:x2, y:y2}]);
            context2d.stroke();

            // draw grids
            context2d.strokeStyle = this.data("gridColor");
            context2d.lineWidth = this.data("gridLineWidth");
            context2d.beginPath();
            var i = 1, iLen = this.categorys.length - 1, dest = 0.0;
            var categoryUnit = (this.chartWidth - 2 * this.LINE_CHART_OFFSET) / (this.categorys.length - 1); // x轴画线需要间隔的距离
            for(xstep = this.data("gridXStep"), i = xstep; i < iLen; i+= xstep){
                dest = this.LINE_CHART_OFFSET + i * categoryUnit;
                drawLines(context2d, [{x:dest, y:this.LINE_CHART_OFFSET}, {x:dest, y:this.chartHeight - this.LINE_CHART_OFFSET}]);
            }
            if(this.data("showLastSplitLineX")){
                dest = this.chartWidth - this.LINE_CHART_OFFSET;
                drawLines(context2d, [{x:dest, y:this.LINE_CHART_OFFSET}, {x:dest, y:this.chartHeight - this.LINE_CHART_OFFSET}]);
            }

            var valueUnit = (this.chartHeight - 2 * this.LINE_CHART_OFFSET) / (this.values.length - 1);  // y轴画线需要间隔的距离
            for(ystep = this.data("gridYStep"), i = ystep, iLen = this.values.length - 1; i < iLen; i+=ystep){
                dest = this.chartHeight - this.LINE_CHART_OFFSET - i * valueUnit;
                drawLines(context2d, [{x:this.LINE_CHART_OFFSET, y:dest}, {x:this.chartWidth - this.LINE_CHART_OFFSET, y:dest}]);
            }
            if(this.data("showLastSplitLineY")){
                dest = this.LINE_CHART_OFFSET;
                drawLines(context2d, [{x:this.LINE_CHART_OFFSET, y:dest}, {x:this.chartWidth - this.LINE_CHART_OFFSET, y:dest}]);
            }

            context2d.stroke();
        },

        _drawData:function(){
            var line,
                context2d = this.canvas[0].getContext("2d"),
                width = this.chartWidth - 2 * this.LINE_CHART_OFFSET,
                height = this.chartHeight - 2 * this.LINE_CHART_OFFSET;

            while(this.newLines.length){
                this.lines.push(this.newLines.shift().draw(context2d, width, height, this.maxVal, this.minVal, this.LINE_CHART_OFFSET));
            }
        },

        /**
         * 真正完成添加线对象的方法。
         * @private
         */
        _addData:function(obj){
            line = new Line(obj);
            this.newLines.push(line);

            if(!this.tipsContainer.children().length){
                var $tmp = $("<div style='width:" + this.data("chartOffsetX") +"px;height:25px;margin-right:5px;float:left;'></div>");
                //$tmp.css("width","60");
                this.tipsContainer.append($tmp);
            }

            var $group  = $("<span class='tip-group'></span>");
            var $icon = $("<span class='tip-color' style='background-color:"+obj.color+"'>"+obj.name+":"+"</span>");
            $group.append($icon);
            this.icons.push($icon);

            var $txt = $("<span class='tip-content'></span>");
            $group.append($txt);
            this.tips.push($txt);
            this.tipsContainer.append($group);
        },

        _touchStartEvent:function(event){
            var rect = me.root()[0].getBoundingClientRect();
            me.containerLeft = rect.left + document.body.scrollLeft;
            me.containerTop = rect.top + document.body.scrollTop;

            var touch = event.targetTouches[0];
            var xpos = touch.pageX - (me.containerLeft + me.data("chartOffsetX"));
            var ypos = touch.pageY - (me.containerTop + me.data("chartOffsetY") + me.tipsHeight);
            var line, pt, matched = false;
            for(var i = 0, iLen = me.lines.length; i < iLen; i++){
                line = me.lines[i];
                for(var j = 0, jLen = line.pts.length; j < jLen; j++){
                    pt = line.pts[j];
                    if((Math.abs(xpos - pt.x) + Math.abs(ypos - pt.y)) < me.COLLISION_OFFSET){
                        matched = true;
                        me.tips[i].text(pt.data);
                        me.trigger("baidu_chart_data_selected", [{data:pt.data, name:line.name}]);
                        break;
                    }
                }
                if(matched){
                    break;
                }
            }

            if(!me.data("enableDrag")){
                return;
            }
            isDown = true;

            setTimeout(function(){
                if(isDown){
                    if(me.data("showTouchLine") && matched){
                        me._showTouchIndicator(pt.x);
                    }
                    me.on("touchmove", me._touchMoveEvent);
                }
            }, me.data("touchTimeout"));
        },

        _touchEndEvent:function(event){
            me.off("touchmove", me._touchMoveEvent);
            //
            if(me.data("showTouchLine")){
                me._hideTouchIndicator();
            }
            isDown = false;
        },

        _touchMoveEvent:function(event){
            var touch = event.targetTouches[0];
            var clientX = touch.pageX - (me.containerLeft + me.data("chartOffsetX"));
            var line, pt, eventArr = [];
            for(var i = 0, iLen = me.lines.length; i < iLen; i++){
                line = me.lines[i];
                for(var j = 0, jLen = line.pts.length; j < jLen; j++){
                    pt = line.pts[j];
                    if(Math.abs(clientX - pt.x) < 6){
                        matched = true;
                        me.tips[i].text(pt.data);
                        eventArr.push({data:pt.data, name:line.name});
                        if (me.data("showTouchLine")) {
                            me._moveTouchIndicator(pt.x);
                        }
                    }
                }
            }
            eventArr.length && me.trigger("baidu_chart_data_selected", eventArr);

            event.preventDefault();
        },

        _showTouchIndicator:function(x){
            if(!me.$touchLine){
                me.$touchLine = $("<div class='touch-line'></div>");
                me.$touchLine.css("height", me.chartHeight - 2 * me.LINE_CHART_OFFSET);
                me.$touchLine.css("top", $('#linechart canvas')[0].offsetTop + me.LINE_CHART_OFFSET);
            }

            me.$touchLine.css("left",x + this.data("chartOffsetX"));
            me.root().append(me.$touchLine);
        },

        _moveTouchIndicator:function(x){
            if(!me.$touchLine){
                me.$touchLine = $("<div class='touch-line'></div>");
                me.$touchLine.css("height", me.chartHeight - 2 * me.LINE_CHART_OFFSET);
                me.$touchLine.css("top", $('#linechart canvas')[0].offsetTop + me.LINE_CHART_OFFSET);
            }
            if(!me.$touchLine.parent() || !me.$touchLine.parent().length){
                me.root().append(me.$touchLine);
            }

            me.$touchLine.css("left",x + me.data("chartOffsetX"));
        },

        _hideTouchIndicator:function(){
            me.$touchLine && me.$touchLine.parent() && me.$touchLine.remove();
        },

        /**
         * @private 
         */
        draw:function(){
            if(this.invalidHash[this.INVALID_TYPE.INIT]){
                this._do_init();
            }
            if(this.invalidHash[this.INVALID_TYPE.ALL]){
                this._drawChart();
                this._drawData();
            }
            if(this.invalidHash[this.INVALID_TYPE.DATA]){
                this._drawData();
            }

            $.ui.Chart.prototype.draw.apply(this);
        },

        /**
         * @name    setCategoryGrid
         * @desc    设置横轴标注
         * @param   {Array} 表示横轴标注。
         * @grammar setCategoryGrid(["09pm","10pm","11pm","12pm","01am","02am","03am","04am","05am","06am","07am","08am"]) => instance
         * @example
         * //setup mode
         * $('#linechart').LineChart('setCategoryGrid', ["09pm","10pm","11pm","12pm","01am","02am","03am","04am","05am","06am","07am","08am"]);
         *
         * //render mode
         * var linechart = $.ui.LineChart();
         * linechart.setCategoryGrid(["09pm","10pm","11pm","12pm","01am","02am","03am","04am","05am","06am","07am","08am"]);
         */
        setCategoryGrid:function(value){
            this.categorys = (value || []).concat();
            this.invalide(this.INVALID_TYPE.ALL);
            return this;
        },

        /**
         * @name    setValueGrid
         * @desc    设置纵轴标注
         * @param   {Array} 表示纵轴标注
         * @grammar setValueGrid([0, 20, 40, 60, 80, 100]) => instance
         * @example
         * //setup mode
         * $('#linechart').LineChart('setValueGrid', [0, 20, 40, 60, 80, 100]);
         *
         * //render mode
         * var linechart = $.ui.LineChart();
         * linechart.setValueGrid([0, 20, 40, 60, 80, 100]);
         */
        setValueGrid:function(value){
            this.values = (value || []).concat();
            this.invalide(this.INVALID_TYPE.ALL);
            return this;
        },

        /**
         * @name    setWidth
         * @desc    设置图表宽度
         * @param   {Number} 设置图表宽度
         * @grammar setWidth(800) => instance
         * @example
         * //setup mode
         * $('#linechart').LineChart('setWidth', 800);
         *
         * //render mode
         * var linechart = $.ui.LineChart();
         * linechart.setWidth(800);
         */
        setWidth:function(value){
            this.chartWidth = value;
            this._data.width = value;

            this._do_init();
            var tmpLines = this.lines.splice(0, this.lines.length);
            var tmpObjs, obj;
            for(var i = 0, iLen = tmpLines.length; i < iLen; i++){
                tmpObjs = tmpObjs || [];
                obj = {type:tmpLines[i].type, name:tmpLines[i].name, data:tmpLines[i].data.concat(), color:tmpLines[i].color};
                tmpObjs.push(obj);
            }
            //tmpObjs.length && this.setData(tmpObjs);
            this.setData(tmpObjs);
            return this;
        },

        /**
         * @name    setHeight
         * @desc    设置图表高度
         * @param   {Number} 设置图表高度
         * @grammar setHeight(240) => instance
         * @example
         * //setup mode
         * $('#linechart').LineChart('setHeight', 240);
         *
         * //render mode
         * var linechart = $.ui.LineChart();
         * linechart.setHeight(240);
         */
        setHeight:function(value){
            this.chartHeight = value;
            this._data.height = value;

            this._do_init();
            var tmpLines = this.lines.splice(0, this.lines.length);
            var tmpObjs, obj;
            for(var i = 0, iLen = tmpLines.length; i < iLen; i++){
                tmpObjs = tmpObjs || [];
                obj = {type:tmpLines[i].type, name:tmpLines[i].name, data:tmpLines[i].data.concat(), color:tmpLines[i].color};
                tmpObjs.push(obj);
            }
            //tmpObjs.length && this.setData(tmpObjs);
            this.setData(tmpObjs);
            return this;
        },

        /**
         * @name    clear
         * @desc    清除绘制的数据
         * @grammar clear() => instance
         * @example
         * //setup mode
         * $('#linechart').LineChart('clear');
         *
         * //render mode
         * var linechart = $.ui.LineChart();
         * linechart.clear();
         */
        clear:function(){
            this.lines.splice(0, this.lines.length);
            this.newLines.splice(0, this.newLines.length);
            this.tips = [];
            this.icons = [];

            this.tipsContainer[0].innerHTML = "";
            this._do_init();
            this._drawChart();

            $.ui.Chart.prototype.clear.apply(this);
            return this;
        },

        /**
         * @name setData
         * @desc 设置数据对象。
         * @param  {Array} Object数组。数组中每一个元素的格式为{type:..., name:..., data:..., color:...}
         * @grammar setData([{type:"diamond", name:"graph1", data:[100,10,20,30,20,50,60,40,50,40,50,40], color:"#0000ff"}]) => instance
         * @example
         * //setup mode
         * $('#linechart').LineChart('setData', [{type:"diamond", name:"graph1", data:[100,10,20,30,20,50,60,40,50,40,50,40], color:"#0000ff"}]);
         *
         * //render mode
         * var linechart = $.ui.LineChart();
         * linechart.setData([{type:"diamond", name:"graph1", data:[100,10,20,30,20,50,60,40,50,40,50,40], color:"#0000ff"}]);
         */
        setData:function(arr){
            if(!arr){
                $.ui.Chart.prototype.setData.apply(this, [arr]);
                return;
            }
            this.lines.splice(0, this.lines.length);
            this.newLines.splice(0, this.newLines.length);
            this.tips = [];
            this.icons = [];
            this.tipsContainer[0].innerHTML = "";

            for(var i = 0, iLen = arr.length; i < iLen; i++){
                this._addData(arr[i]);
            }

            $.ui.Chart.prototype.setData.apply(this, [arr]);
            return this;
        },

        /**
         * @name addData
         * @desc 增加数据对象
         * @param  {Object} 线数据对象，对象的格式为{type:..., name:..., data:..., color:...}
         * @grammar addData({"type":"baidu.dv.line.LineGraph", "name":"graph5", "data":[80,50,40,80,20,50,70,20,60,20,80,70], color:"#ff00ff"}) => instance
         * @example
         * //setup mode
         * $('#linechart').LineChart('addData', {"type":"baidu.dv.line.LineGraph", "name":"graph5", "data":[80,50,40,80,20,50,70,20,60,20,80,70], color:"#ff00ff"});
         *
         * //render mode
         * var linechart = $.ui.LineChart();
         * linechart.addData({"type":"baidu.dv.line.LineGraph", "name":"graph5", "data":[80,50,40,80,20,50,70,20,60,20,80,70], color:"#ff00ff"});
         */
        addData:function(obj){
            this._addData(obj);
            $.ui.Chart.prototype.addData.apply(this, [obj]);
            return this;
        }
    });

    function drawLines(context, pts){
        var x1 = pts[0].x, y1 = pts[0].y, x2, y2;
        for(var i = 0, iLen = pts.length - 1; i < iLen; i++){
            x2 = pts[i+1].x;
            y2 = pts[i+1].y;

            if(x1 == x2){
                x1 = Math.round(x1) + 0.5;
                x2 = x1;
            } else if(y1 == y2){
                y1 = Math.round(y1) + 0.5;
                y2 = y1;
            }

            if(i == 0){
                context.moveTo(x1, y1);
            }
            context.lineTo(x2, y2);

            x1 = x2;
            y1 = y2;
        }
    }

    // 内部类Line
    function Line(obj){
        this.name = obj.name;
        this.data = obj.data;
        this.color = obj.color;
        this.type = obj.type;
        this.pts = [];
    }

    Line.prototype.draw = function(context2d, chartWidth, chartHeight, maxVal, minVal, LINE_CHART_OFFSET){
        // 画线
        context2d.strokeStyle = this.color;
        context2d.lineWidth = 2;
        context2d.beginPath();

        var tmpy = 0.0, ratio = chartHeight / (maxVal - minVal), categoryUnit = chartWidth / (this.data.length - 1);
        var tmpArr = [];
        for(var i = 0, iLen = this.data.length; i < iLen; i++){
            tmpy = LINE_CHART_OFFSET + chartHeight - (this.data[i] - me.minVal) * ratio;
            //if(i == 0){
            //  context2d.moveTo(i * categoryUnit + LINE_CHART_OFFSET, tmpy);
            //} else {
            //  context2d.lineTo(i * categoryUnit + LINE_CHART_OFFSET, tmpy);
            //}
            tmpArr.push({x:i * categoryUnit + LINE_CHART_OFFSET, y:tmpy});
            this.pts.push({x:i * categoryUnit + LINE_CHART_OFFSET, y:tmpy, data:this.data[i]});
        }
        drawLines(context2d, tmpArr);
        context2d.stroke();

        var pt;
        if(this.type == "circle"){
            // 画点
            for(i = 0, iLen = this.pts.length; i < iLen; i++){
                pt = this.pts[i];
                context2d.beginPath();
                context2d.fillStyle = "#ffffff";
                context2d.strokeStyle = this.color;
                context2d.arc(pt.x, pt.y, 3, 0, 2 * Math.PI, true);
                context2d.stroke();
                context2d.fill();
            }
        } else if(this.type == "diamond"){
            // 画点
            for(i = 0, iLen = this.pts.length; i < iLen; i++){
                pt = this.pts[i];
                context2d.beginPath();
                context2d.fillStyle = "#ffffff";
                context2d.strokeStyle = this.color;
                context2d.moveTo(pt.x - 3, pt.y);
                context2d.lineTo(pt.x, pt.y - 3);
                context2d.lineTo(pt.x + 3, pt.y);
                context2d.lineTo(pt.x, pt.y + 3);
                context2d.lineTo(pt.x - 3, pt.y);
                context2d.stroke();
                context2d.fill();
            }
        } else if(this.type == "rect"){
            // 画点
            for(i = 0, iLen = this.pts.length; i < iLen; i++){
                pt = this.pts[i];
                context2d.beginPath();
                context2d.fillStyle = "#ffffff";
                context2d.strokeStyle = this.color;
                context2d.moveTo(pt.x - 3, pt.y - 3);
                context2d.lineTo(pt.x - 3, pt.y + 3);
                context2d.lineTo(pt.x + 3, pt.y + 3);
                context2d.lineTo(pt.x + 3, pt.y - 3);
                context2d.lineTo(pt.x - 3, pt.y - 3);
                context2d.stroke();
                context2d.fill();
            }
        }
        return this;
    }
})();

