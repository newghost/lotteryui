/*
master functionalities.
*/
(function(window, document) {

  var master = EL.Master = function(model) {

    var $tree = $("#tree"),
        $logout = $("#aLogout"),
        curOpts = {};

    /*
    set tree on the left panel
    */
    master.setTree = function() {

      var tree = [];

      //click the tree handler
      var clickTree = function(node) {
        var id = node.id,
            attr = node.attributes;

        curOpts = attr;

        Lottery.add(id, '');
        Lottery.mvto(id);

        $.ajax({
          url: id + ".html",
          type: "post", data: EL.Auth.getTocken(),
          dataType: "html",
          success: function(html) {
            Lottery.html(id, html);
          }
        });
      };

      var refreshTimer = null;

      var onClickTree = function(node){
        window.clearTimeout(refreshTimer);
        refreshTimer = window.setTimeout(function() {
          clickTree(node);
        }, 500);
      };

      var parseTree = function(data) {
        var i = 0, len = data.length;
        EL.Master.pducount = len;
        for(; i < len; i++) {
          var obj = data[i],
              pdu = {
                "id": "pdus",
                "text": obj.name,
                "children":[],
                attributes: {
                  pduid: i + 1
                }
              };

          obj["ess"] = 1;

          for(var key in EL.TreeMap) {

            var val = parseInt(obj[key]);

            if (i == 0) {
              //Set the pdu name in the Privilge;
              EL.Privilege.pdu = obj.name;
              //reset number of the outlets
              (key == "outs") && EL.Privilege.setOutCount(val);
            }

            if (val) {
              var node = {
                id: EL.TreeMap[key]["id"],
                text: EL.TreeMap[key]["text"],
                iconCls: EL.TreeMap[key]["icon"],
                attributes: { pduid: i + 1 }
              };
              if (key == "outs") {
                node.state = "closed";
                node.children = [];

                for(var o = 1, oLen = val; o <= oLen; o++) {
                  node.children.push({
                    //id:"outlet " + o ,
                    id:"outlet",
                    // text: OUTLETS[1 << (o - 1)],
                    text: OUTLETS[(1 << (o - 1)) < 0 ? -(1 << (o - 1)) : (1 << (o - 1))],
                    iconCls:"icon-ol",
                    attributes: {
                      pduid: i + 1,
                      outid: o
                    }
                  });
                }
              }
              pdu.children.push(node);
            }
          }
          tree.push(pdu);
        }

        //Create treeview

        $tree.tree({      
          checkbox: false,
          data: tree,
          onClick: onClickTree
        });
      };

      $.ajax({contentType: "application/json",
        url:"xhrpdutree.jsp",
        type:"post", data: EL.Auth.getTocken(),
        dataType:"json",
        success: parseTree,
        error:function() {
          console.log(arguments);
        }
      });
    };

    /*
    Set environments
    */
    master.logintime = new Date();
    master.curtime = new Date();
    master.ip = "127.0.0.1";

    master.init = function() {

      var //$downloadDiagnostics = $("#downloadDiagnostics"),
          $loginuser = $("#loginuser"),
          $ipaddress = $("#logintime"),
          $currenttime = $("#currenttime"),
          formatTime = function() {
            var strTime = master.curtime.toString(),
                idxGMT = strTime.indexOf("GMT");

            (idxGMT < 0) && (idxGMT = strTime.indexOf("UTC"));

            return strTime.substr(0, idxGMT);
          };

      var environmentHandler = function(data) {
        //datatime
        master.ip = data.ip;
        master.curtime = new Date(data.curtime);
        master.logintime = master.curtime;

        var updateCurrentTime = function() {
          $currenttime.html(formatTime());
          master.curtime = new Date(1000 + +master.curtime);
        };

        window.setInterval(updateCurrentTime, 1000);

        updateCurrentTime();

        //power tip commited.
        $loginuser
          .html( data.name + " ( " + data.role + " ) " )
          .attr("title", model.login.format(data.role));

        $ipaddress
          .attr("title", model.ip.format(master.ip));

        $currenttime
          .attr("title", model.time.format(formatTime()));

        //privilege
        EL.Privilege.set(data);

        //force change password
        if (EL.Privilege.changepsw) {
          $("#changepw")
            .data("dlgclass", "forcedlg")
            .click()
            .data("dlgclass", "");
        }

        //set tree
        master.setTree();
        //init force https
        //EL.ForceHttps();
        //init set alarm dialog
        //EL.SetAlarm().init();
      };

      //update download url
      $.ajax({
        url: "xhrmasterpgget.jsp", contentType: "application/json",
        type: "post", dataType: "json",
        data: EL.Auth.getTocken(),
        success: environmentHandler
      });

    };


    return master;
  };

  /*
  public method, need not initialization
  */
  master.getTabOpts = function($el) {
    return curOpts;
  };

  //pdu count
  master.pducount = 0;

})(window, document);